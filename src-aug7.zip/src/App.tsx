import React, { useState } from 'react';
import { Header } from './components/Header';
import { AnalyticsDashboard } from './components/AnalyticsDashboard';
import { DateRangePicker } from './components/DateRangePicker';

function App() {
  const [startDate, setStartDate] = useState('2025-08-1');
  const [endDate, setEndDate] = useState('2025-08-2');
  const [propertyId, setPropertyId] = useState<string>('');

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="p-6">
        {/* Page Title */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Analytics Dashboard</h1>
        </div>

        {/* Date Range Picker */}
        <div className="mb-8">
          <DateRangePicker
            startDate={startDate}
            endDate={endDate}
            propertyId={propertyId}
            onStartDateChange={setStartDate}
            onEndDateChange={setEndDate}
            onPropertyIdChange={setPropertyId}
          />
        </div>



        {/* Analytics Dashboard */}
        <AnalyticsDashboard 
          startDate={startDate || '2025-08-1'}
          endDate={endDate || '2025-08-2'}
          propertyId={propertyId || undefined}
        />
      </main>
    </div>
  );
}

export default App;