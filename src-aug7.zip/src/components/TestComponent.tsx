import React from 'react';

export const TestComponent: React.FC = () => {
  return (
    <div className="p-8 bg-blue-100 rounded-lg">
      <h1 className="text-2xl font-bold text-blue-900 mb-4">Test Component</h1>
      <p className="text-blue-700">If you can see this, React is working!</p>
      <div className="mt-4 p-4 bg-white rounded border">
        <p className="text-gray-800">Current time: {new Date().toLocaleString()}</p>
      </div>
    </div>
  );
}; 